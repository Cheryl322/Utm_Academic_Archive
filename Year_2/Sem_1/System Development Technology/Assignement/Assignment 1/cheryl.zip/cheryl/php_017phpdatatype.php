<!DOCTYPE html>
<html>
<body>

<?php 
$x = "Hello world!";
$y = 'Hello world!';

var_dump($x);
echo "<br>"; 
var_dump($y);
?>

<hr>
<?php  
$x = 5985;
var_dump($x);
?> 

<hr>
<?php  
$x = 10.365;
var_dump($x);
?> 

<hr>
<?php 
$x = true;
var_dump($x);
?>

<hr>
<?php  
$cars = array("Volvo","BMW","Toyota");
var_dump($cars);
?>  

<hr>
<?php
class Car {
  public $color;
  public $model;
  public function __construct($color, $model) {
    $this->color = $color;
    $this->model = $model;
  }
  public function message() {
    return "My car is a " . $this->color . " " . $this->model . "!";
  }
}

$myCar = new Car("red", "Volvo");
var_dump($myCar);
?>

<hr>
<?php
$x = "Hello world!";
$x = null;
var_dump($x);
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
