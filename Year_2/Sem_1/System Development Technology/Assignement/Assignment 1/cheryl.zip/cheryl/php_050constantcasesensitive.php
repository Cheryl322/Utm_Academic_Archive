<!DOCTYPE html>
<html>
<body>

<?php
echo "case-sensitive constant name";
define("GREETING", "Welcome to W3Schools.com!");
echo GREETING;
?> 

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
