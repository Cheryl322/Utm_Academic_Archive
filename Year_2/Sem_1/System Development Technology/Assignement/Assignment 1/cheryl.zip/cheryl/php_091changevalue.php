<!DOCTYPE html>
<html>
<body>
<pre>

<?php
$cars = array("Volvo", "BMW", "Toyota"); 
$cars[1] = "Ford";
var_dump($cars);
?>

</pre>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>