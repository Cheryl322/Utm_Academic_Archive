<!DOCTYPE html>
<html>
<body>

<?php
echo "Use a regular expression to do a case-insensitive search for "w3schools" in a string: <br>";
$str = "Visit W3Schools";
$pattern = "/w3schools/i";
echo preg_match($pattern, $str); 
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>