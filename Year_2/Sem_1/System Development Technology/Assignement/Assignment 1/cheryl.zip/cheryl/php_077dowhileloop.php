<!DOCTYPE html>
<html>
<body>

<?php  
echo "Print i as long as i is less than 6:";
$i = 1;

do {
  echo $i;
  $i++;
} while ($i < 6);
?>  

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>