<!DOCTYPE html>
<html>
<body>

<?php
function add_five(&$value) {
  $value += 5;
}

$num = 2;
add_five($num);
echo $num;
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
