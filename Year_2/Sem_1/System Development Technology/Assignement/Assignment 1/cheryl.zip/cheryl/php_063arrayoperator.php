<!DOCTYPE html>
<html>
<body>

<?php
echo "array("a" => "red", "b" => "green") <br> array("c" => "blue", "d" => "yellow") <br>";

$x = array("a" => "red", "b" => "green");  
$y = array("c" => "blue", "d" => "yellow");  
echo " x+y <br>";
print_r($x + $y); // union of $x and $y
?>  

<hr>
<?php
$x = array("a" => "red", "b" => "green");  
$y = array("c" => "blue", "d" => "yellow");  
echo " x==y <br>";
var_dump($x == $y);
?>

<hr>
<?php
$x = array("a" => "red", "b" => "green");  
$y = array("c" => "blue", "d" => "yellow");  
echo " x===y <br>";
var_dump($x === $y);
?> 

<hr>
<?php
$x = array("a" => "red", "b" => "green");  
$y = array("c" => "blue", "d" => "yellow");  
echo " x!=y <br>";
var_dump($x != $y);
?> 

<hr>
<?php
$x = array("a" => "red", "b" => "green");  
$y = array("c" => "blue", "d" => "yellow");  
echo " x<>y <br>";
var_dump($x <> $y);
?>

<hr>
<?php
$x = array("a" => "red", "b" => "green");  
$y = array("c" => "blue", "d" => "yellow");  
echo " x!==y <br>";
var_dump($x !== $y);
?>   


<br><br><a href="index.html">Back</a><br><br>

</body>
</html>