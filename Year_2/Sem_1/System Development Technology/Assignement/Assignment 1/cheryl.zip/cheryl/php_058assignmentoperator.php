<!DOCTYPE html>
<html>
<body>

<?php
echo "x = ";
$x = 10;  
echo $x;
?> 

<hr>
<?php
echo "x = 20+100 <br> x= ";
$x = 20;  
$x += 100;

echo $x;
?>  

<hr>
<?php
echo "x = 50-30 <br> x= ";
$x = 50;  
$x -= 30;

echo $x;
?>  

<hr>
<?php
echo "x = 5*6 <br> x= ";
$x = 5;  
$x *= 6;

echo $x;
?>  

<hr>
<?php
echo "x = 10/5 <br> x= ";
$x = 10;  
$x /= 5;

echo $x;
?> 

<hr>
<?php
echo "x = 15%4 <br> x= ";
$x = 15;  
$x %= 4;

echo $x;
?>   

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
