<!DOCTYPE html>
<html>
<body>

<?php
echo "a=13 ,>10 but <20 <br>";
$a = 13;

if ($a > 10) {
  echo "Above 10";
  if ($a > 20) {
    echo " and also above 20";
  } else {
    echo " but not above 20";
  }
}
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
