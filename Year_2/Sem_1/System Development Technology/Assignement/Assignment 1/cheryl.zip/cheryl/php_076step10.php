<!DOCTYPE html>
<html>
<body>

<?php  
echo "If you want the while loop count to 100, but only by each 10, you can increase the counter by 10 instead 1 in each iteration:";
$i = 0;

while ($i < 100) {
  $i+=10;
  echo "$i<br>";
}
?>  

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
