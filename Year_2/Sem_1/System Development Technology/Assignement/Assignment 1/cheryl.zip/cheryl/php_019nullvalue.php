<!DOCTYPE html>
<html>
<body>

<?php
$x = "Hello world!";
$x = null;
var_dump($x);
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>