<!DOCTYPE html>
<html>
<body>

<p>Invalid calculation will return a NaN value</p>
<?php
// Invalid calculation will return a NaN value
$x = acos(8);
var_dump($x);
?>  

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>