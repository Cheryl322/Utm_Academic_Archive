<!DOCTYPE html>
<html>
<body>

<?php
echo "Output "Have a good day!" if 5 is larger than 3: <br>";
if (5 > 3) {
  echo "Have a good day!";
}
?>

<hr>
<?php
echo "Output "Have a good day!" if $t is less than 20: <br>";
$t = 14;

if ($t < 20) {
  echo "Have a good day!";
}
?>
 
<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
