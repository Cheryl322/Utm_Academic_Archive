<!DOCTYPE html>
<html>
<body>

<?php
echo "round off 0.60";
echo "<br>";
echo(round(0.60) . "<br>");

echo "round off 0.50";
echo "<br>";
echo(round(0.50) . "<br>");

echo "round off 0.49";
echo "<br>";
echo(round(0.49) . "<br>");

echo "round off -4.40";
echo "<br>";
echo(round(-4.40) . "<br>");

echo "round off -4.60";
echo "<br>";
echo(round(-4.60));


?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
