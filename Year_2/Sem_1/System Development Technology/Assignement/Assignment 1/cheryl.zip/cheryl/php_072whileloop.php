<!DOCTYPE html>
<html>
<body>

<?php  
echo "Print i as long as i is less than 6:";
$i = 1;

while ($i < 6) {
  echo $i;
  $i++;
} 
?>  

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
