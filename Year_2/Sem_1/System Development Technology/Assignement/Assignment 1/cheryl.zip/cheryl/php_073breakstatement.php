<!DOCTYPE html>
<html>
<body>

<?php  
echo "Stop the loop when $i is 3:";
$i = 1;

while ($i < 6) {
  if ($i == 3) break;  
  echo $i;
  $i++;
} 
?>  

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
