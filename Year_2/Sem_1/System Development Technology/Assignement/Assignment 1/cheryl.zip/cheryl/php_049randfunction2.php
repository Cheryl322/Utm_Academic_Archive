<!DOCTYPE html>
<html>
<body>

<?php
echo "random number between 10-100";
echo "<br>";
echo(rand(10, 100));
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
