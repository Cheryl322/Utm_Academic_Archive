<!DOCTYPE html>
<html>
<body>

<?php
$x = "Hello World!";
$y = explode(" ", $x);

//Use the print_r() function to display the result:
print_r($y);
?> 

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
