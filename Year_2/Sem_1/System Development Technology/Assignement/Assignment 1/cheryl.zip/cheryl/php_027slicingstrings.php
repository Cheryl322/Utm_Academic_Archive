<!DOCTYPE html>
<html>
<body>

<p>slice to the end</p>
<?php
$x = "Hello World!";
echo substr($x, 6);
?> 

<br><p>slice from the end(从后面开始算然后那三个）</p>
<?php
$x = "Hello World!";
echo substr($x, -5, 3);
?>

<br>
<p>Negative length(From the string "Hi, how are you?", get the characters starting from index 5, and continue until you reach the 3. character from the end (index -3))</p>
<?php
$x = "Hi, how are you?";
echo substr($x, 5, -3);
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
