<!DOCTYPE html>
<html>
<body>

<?php  
for ($x = 0; $x <= 10; $x++) {
  echo "The number is: $x <br>";
}
?>  

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
