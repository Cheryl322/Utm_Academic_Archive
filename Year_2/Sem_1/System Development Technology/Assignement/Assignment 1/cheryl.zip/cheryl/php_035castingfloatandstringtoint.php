<!DOCTYPE html>
<html>
<body>

<?php
echo "Cast float to int"
echo "<br>" 
$x = 23465.768;
$int_cast = (int)$x;
echo $int_cast;
  
echo "<br>";

// Cast string to int
$x = "23465.768";
$int_cast = (int)$x;
echo $int_cast;
?>  

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
