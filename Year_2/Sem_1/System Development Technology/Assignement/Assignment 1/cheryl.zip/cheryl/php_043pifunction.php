<!DOCTYPE html>
<html>
<body>

<?php
echo(pi());
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
