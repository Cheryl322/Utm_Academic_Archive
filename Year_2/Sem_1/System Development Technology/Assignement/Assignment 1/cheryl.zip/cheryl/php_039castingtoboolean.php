<!DOCTYPE html>
<html>
<body>

<ul>
	<li>$a = 5;       // Integer</li>
	<li>$b = 5.34;    // Float</li>
	<li>$c = "0"; // Integer</li>
	<li>$d = "-1"; // Integer</li>
	<li>$e = "0.1"; // Float</li>
	<li>$f = "hello"; // String</li>
	<li>$g = ""; // String</li>
	<li>$h = true;    // Boolean</li>
	<li>$i = NULL;    // NULL</li>
</ul>
<pre>
<?php
$a = 5;       // Integer
$b = 5.34;    // Float
$c = 0;       // Integer
$d = -1;      // Integer
$e = 0.1;     // Float
$f = "hello"; // String
$g = "";      // String
$h = true;    // Boolean
$i = NULL;    // NULL

$a = (bool) $a;
$b = (bool) $b;
$c = (bool) $c;
$d = (bool) $d;
$e = (bool) $e;
$f = (bool) $f;
$g = (bool) $g;
$h = (bool) $h;
$i = (bool) $i;

//To verify the type of any object in PHP, use the var_dump() function:
var_dump($a);
var_dump($b);
var_dump($c);
var_dump($d);
var_dump($e);
var_dump($f);
var_dump($g);
var_dump($h);
var_dump($i);
?> 
</pre>

<p>If a value is 0, NULL, false, or empty, the (bool) converts it into false, otherwise true. Even -1 converts to true.</p>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
