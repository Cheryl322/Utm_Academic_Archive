<!DOCTYPE html>
<html>
<body>
<pre>

<?php
$car = array("brand"=>"Ford", "model"=>"Mustang", "year"=>1964);
var_dump($car);
?>


</pre>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
