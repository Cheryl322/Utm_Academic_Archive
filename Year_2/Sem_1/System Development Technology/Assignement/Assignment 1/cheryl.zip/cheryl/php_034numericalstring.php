<!DOCTYPE html>
<html>
<body>


<?php
echo "Check if the variable is numeric";   
echo "<br>";
$x = 5985;
var_dump(is_numeric($x));

echo "<br>";

$x = "5985";
var_dump(is_numeric($x));

echo "<br>";

$x = "59.85" + 100;
var_dump(is_numeric($x));

echo "<br>";

$x = "Hello";
var_dump(is_numeric($x));
?>  

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>