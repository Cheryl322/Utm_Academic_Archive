<!DOCTYPE html>
<html>
<body>
<pre>

<?php  
echo "Remove the first item: <br>";
$cars = array("Volvo", "BMW", "Toyota");
array_shift($cars);
var_dump($cars);
?>  

</pre>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
