<!DOCTYPE html>
<html>
<body>

<p>If a match is found, the function returns the character position of the first match. If no match is found, it will return FALSE.</p><br>
<p>Search for the text "world" in the string "Hello world!"</p>
<?php
echo strpos("Hello world!", "world");
?> 
 
<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
