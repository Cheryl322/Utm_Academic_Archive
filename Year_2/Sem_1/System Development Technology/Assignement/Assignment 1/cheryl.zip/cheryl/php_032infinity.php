<!DOCTYPE html>
<html>
<body>

<p>Check if a numeric value is finite or infinite</p>

<?php
// Check if a numeric value is finite or infinite 
$x = 1.9e411;
var_dump($x);
?>  

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>