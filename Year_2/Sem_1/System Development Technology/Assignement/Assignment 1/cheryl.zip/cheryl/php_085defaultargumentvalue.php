<!DOCTYPE html>
<html>
<body>

<?php
function setHeight($minheight = 50) {
  echo "The height is : $minheight <br>";
}

setHeight(350);
setHeight();
echo "will use the default value of 50 <br>";
setHeight(135);
setHeight(80);
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>