<!DOCTYPE html>
<html>
<body>

<?php
$x = "John";
echo $x;
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>