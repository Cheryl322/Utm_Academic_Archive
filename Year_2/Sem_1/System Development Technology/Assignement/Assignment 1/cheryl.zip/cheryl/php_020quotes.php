<!DOCTYPE html>
<html>
<body>

<p>Double Quotes</p>
<?php
$x = "John";
echo "Hello $x";
?>

<hr>
<p>Single Quotes</p>
<?php
$x = "John";
echo 'Hello $x';
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>