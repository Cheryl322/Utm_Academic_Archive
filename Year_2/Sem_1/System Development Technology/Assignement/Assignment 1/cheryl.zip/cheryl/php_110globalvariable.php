<!DOCTYPE html>
<html>
<body>

<?php 
echo "Refer to the global variable $x inside a function: <br>"; 
$x = 75;
  
function myfunction() {
  echo $GLOBALS['x'];
}

myfunction()
?> 

<hr>
<?php 
echo "Define $x as global inside a function: <br>"; 
$x = 75;
  
function myfunction() {
  global $x;
  echo $x;
}

myfunction()
?>   

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
