<!DOCTYPE html>
<html>
<body>

<pre>
<?php  
$cars = array("brand" => "Ford", "model" => "Mustang");
$cars += ["color" => "red", "year" => 1964];

//Output the array:
var_dump($cars);
?>
</pre>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>