<!DOCTYPE html>
<html>
<body>

<?php
echo(abs(-6.7));
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>