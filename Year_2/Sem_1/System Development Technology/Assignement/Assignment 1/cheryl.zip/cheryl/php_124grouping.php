<!DOCTYPE html>
<html>
<body>

<?php
$str = "Apples and bananas.";
$pattern = "/ba(na){2}/i";
echo preg_match($pattern, $str);
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
