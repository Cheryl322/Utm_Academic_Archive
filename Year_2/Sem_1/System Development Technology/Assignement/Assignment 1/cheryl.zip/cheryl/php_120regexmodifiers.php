<!DOCTYPE html>
<html>
<body>

<h2>Regex Modifier: i (Performs a case-insensitive search)</h2>

<p>How many occurences of the letter s is in the text "W3Schools":</p>

<?php
$txt = "W3Schools";
$pattern = "/s/i";
echo preg_match_all($pattern, $txt);
?>  

<p>The matches were found here:</p>

<?php
echo preg_replace($pattern, "#", $txt);
?>  

<p>(Each match was replaced by a # character)</p>


<hr>
<h2>Regex Modifier: m (Performs a multiline search)</h2>

<p>How many times does the phrase "you" occur at the beginning of a line in the text:</p>

<pre>you are better than
you think</pre>

<?php
$txt1 = "you are better than\nyou think";
$pattern1 = "/^you/m";
echo preg_match_all($pattern1, $txt1);
?>  

<p>The matches were found here:</p>

<pre>
<?php
echo preg_replace($pattern1, "#", $txt1);
?>  
</pre>

<p>(Each match was replaced by a # character)</p>


<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
