<!DOCTYPE html>
<html>
<body>

<p>Word Count</p>
<?php
echo str_word_count("Hello world!");
?> 
 
<br><br><a href="index.html">Back</a><br><br>

</body>
</html>