<!DOCTYPE html>
<html>
<body>
<pre>

<?php  
$myArr = [];
$myArr[0] = "apples";
$myArr[1] = "bananas";
$myArr["fruit"] = "cherries";

var_dump($myArr);
?>  

</pre>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>