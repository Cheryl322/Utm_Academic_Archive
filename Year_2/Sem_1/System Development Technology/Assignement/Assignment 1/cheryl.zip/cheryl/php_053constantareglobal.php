<!DOCTYPE html>
<html>
<body>

<?php
define("GREETING", "Welcome to W3Schools.com!");

function myTest() {
  echo GREETING;
}
 
myTest();
echo "Constants are automatically global and can be used across the entire script.";
?> 

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>