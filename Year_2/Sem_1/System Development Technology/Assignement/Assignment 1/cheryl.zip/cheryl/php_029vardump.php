<!DOCTYPE html>
<html>
<body>

<?php
$a = 5;
$b = 5.34;
$c = "25";

var_dump($a);
echo "<br>";
var_dump($b);
echo "<br>";
var_dump($c);
?> 

<p>Line breaks were added for better readability.</p>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
