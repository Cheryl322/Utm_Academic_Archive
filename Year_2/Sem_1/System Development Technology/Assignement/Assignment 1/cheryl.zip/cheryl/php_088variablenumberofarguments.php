<!DOCTYPE html>
<html>
<body>

<?php
function myFamily($lastname, ...$firstname) {
  $txt = "";
  $len = count($firstname);
  for($i = 0; $i < $len; $i++) {
    $txt = $txt."Hi, $firstname[$i] $lastname.<br>";
  }
  return $txt;
}
//。。。一点要在中间不可以在第一个
$a = myFamily("Doe", "Jane", "John", "Joey");
echo $a;
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
