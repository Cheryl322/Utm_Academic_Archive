<!DOCTYPE html>
<html>
<body>

<?php
echo "if 5<10 write hello";
$a = 5;

if ($a < 10) $b = "Hello";

echo $b
?>

<hr>
<?php
echo "if 13<10 write hello else write good bye";
$a = 13;

$b = $a < 10 ? "Hello" : "Good Bye";

echo $b;
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
