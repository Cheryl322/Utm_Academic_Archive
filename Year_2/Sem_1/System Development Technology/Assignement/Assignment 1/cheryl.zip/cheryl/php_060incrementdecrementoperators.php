<!DOCTYPE html>
<html>
<body>

<?php
echo "x=10 <br> ++x <br>";
$x = 10;  
echo ++$x;
?>  

<hr>
<?php
echo "<br> x++ <br>";
$x = 10;  
echo $x++;
?>

<hr>
<?php
echo "<br> --x <br>";
$x = 10;  
echo --$x;
?>   

<hr>
<?php
echo "<br> x-- <br>";
$x = 10;  
echo $x--;
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>