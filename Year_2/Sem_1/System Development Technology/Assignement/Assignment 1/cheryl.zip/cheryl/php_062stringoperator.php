<!DOCTYPE html>
<html>
<body>

<?php
echo "Hello . World, . means +";
$txt1 = "Hello";
$txt2 = " world!";
echo $txt1 . $txt2;
?>  

<hr>
<?php
echo "Hello .= World, . means +";
$txt1 = "Hello";
$txt2 = " world!";
$txt1 .= $txt2;
echo $txt1;
?> 

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>