<!DOCTYPE html>
<html>
<body>

<?php
$txt = "W3Schools.com";
echo "I love $txt!";
?>

<?php
$x = 5;
$y = 4;
echo $x + $y;
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
