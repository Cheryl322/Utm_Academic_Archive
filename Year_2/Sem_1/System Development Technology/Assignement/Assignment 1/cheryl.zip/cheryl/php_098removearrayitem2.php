<!DOCTYPE html>
<html>
<body>
<pre>

<?php  
echo "With the array_splice() function you specify the index (where to start) and how many items you want to delete. <br>";
$cars = array("Volvo", "BMW", "Toyota");
array_splice($cars, 1, 2);
var_dump($cars);
?>  

</pre>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>