<?php
namespace myArea;

function myValue(){
  return __NAMESPACE__;
}
?>
<!DOCTYPE html>
<html>
<body>

<?php
echo myValue();
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
