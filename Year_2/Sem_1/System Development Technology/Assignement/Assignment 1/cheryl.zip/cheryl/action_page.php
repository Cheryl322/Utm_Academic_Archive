<!DOCTYPE html>
<html>
<body>

<h2>Submitted Form Data</h2>

<?php
// Check if form data was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect values from the form
    $firstName = htmlspecialchars($_POST['fname']);
    $lastName = htmlspecialchars($_POST['lname']);

    // Display the received input
    echo "<p>Your input was received as:</p>";
    echo "<p>fname=" . $firstName . "&lname=" . $lastName . "</p>";
} else {
    echo "No form data received.";
}
?>

</body>
</html>