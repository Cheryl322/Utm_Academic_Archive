<!DOCTYPE html>
<html>
<body>
<pre>

<?php  
echo "Change ALL item values to Ford: <br>";
$cars = array("Volvo", "BMW", "Toyota");
foreach ($cars as &$x) {
  $x = "Ford";
}
unset($x);
var_dump($cars);
?>  

</pre>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>