<!DOCTYPE html>
<html>
<body>

<?php 
echo "Variables created in the outer most scope are global variables either if they are created using the GLOBALS syntax or not: <br>"; 
$x = 100;

echo $GLOBALS["x"];
echo $x;
?>  

<hr>
<?php 
echo "Create a global variable from inside a function, and use it outside of the function: <br>"; 
function myfunction() {
  $GLOBALS["x"] = 100;
}

myfunction();

echo $GLOBALS["x"];
echo $x;
?>  

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>