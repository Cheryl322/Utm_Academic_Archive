<!DOCTYPE html>
<html>
<body>

<?php
echo "Addition";
echo "<br>";
$x = 10;  
$y = 6;
echo "10+6 = ";
echo $x + $y;
?>

<hr>
<?php
echo "Subtaraction";
echo "<br>";
$x = 10;  
$y = 6;
echo "10-6 = ";
echo $x - $y;
?>

<hr>
<?php
echo "Multipication";
echo "<br>";
$x = 10;  
$y = 6;
echo "10x6 = ";
echo $x * $y;
?>

<hr>
<?php
echo "Division";
echo "<br>";
$x = 10;  
$y = 6;
echo "10/6 = ";
echo $x / $y;
?>

<hr>
<?php
echo "Modulus";
echo "<br>";
$x = 10;  
$y = 6;
echo "10%6 = ";
echo $x % $y;
?>

<hr>
<?php
echo "Exponentiation";
echo "<br>";
$x = 10;  
$y = 3;
echo "10^3 = ";
echo $x ** $y;
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
