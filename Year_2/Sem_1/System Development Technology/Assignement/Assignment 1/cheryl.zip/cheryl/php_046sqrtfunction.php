<!DOCTYPE html>
<html>
<body>

<?php
echo "sqrt(64)";
echo "<br>";
echo(sqrt(64) . "<br>");

echo "sqrt(0)";
echo "<br>";
echo(sqrt(0) . "<br>");

echo "sqrt(1)";
echo "<br>";
echo(sqrt(1) . "<br>");

echo "sqrt(9)";
echo "<br>";
echo(sqrt(9));
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
