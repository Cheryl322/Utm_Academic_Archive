<!DOCTYPE html>
<html>
<body>

<?php
$x = 5;
$y = "John";

echo $x;
echo "<br>";
echo $y;
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
