<!DOCTYPE html>
<html>
<body>

<?php
function myMessage() {
  echo "Hello world!";
}

myMessage();
?> 

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
