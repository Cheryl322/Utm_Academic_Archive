<!DOCTYPE html>
<html>
<body>

<?php
echo "Output (Have a good day!) if the current time is greater than 5, and (Have a good night!) otherwise:";
$t = date("H");

if ($t > "5") {
  echo "Have a good day!";
} else {
  echo "Have a good night!";
}
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
