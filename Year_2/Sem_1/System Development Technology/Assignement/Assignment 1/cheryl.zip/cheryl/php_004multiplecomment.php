<!DOCTYPE html>
<html>
<body>

<?php
/*
The next statement will
print a welcome message
*/
echo "Welcome Home!";
?>
 
<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
