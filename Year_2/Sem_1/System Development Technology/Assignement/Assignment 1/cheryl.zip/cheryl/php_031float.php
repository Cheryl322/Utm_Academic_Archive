<!DOCTYPE html>
<html>
<body>

<p>check 10.365 whether a float or not</p>
<?php
// Check if the type of a variable is float 
$x = 10.365;
var_dump(is_float($x));
?>  

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>