<!DOCTYPE html>
<html>
<body>

<?php
echo "Use a case-insensitive regular expression to replace Microsoft with W3Schools in a string: <br>";
$str = "Visit Microsoft!";
$pattern = "/microsoft/i";
echo preg_replace($pattern, "W3Schools", $str);
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
