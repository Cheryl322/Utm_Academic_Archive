<!DOCTYPE html>
<html>
<body>

<h1>Regex Modifier: cat|dog|fish</h1>

<p>How many occurrences of either "cat", "dog", or "fish" are in the text "We have three dogs, one fish, but no cats":</p>

<?php
$txt = "We have three dogs, one fish, but no cats";
$pattern = "/cat|dog|fish/";
echo preg_match_all($pattern, $txt);
?>  

<p>The matches were found here:</p>

<?php
echo preg_replace($pattern, "#", $txt);
?>  

<p>(Each match was replaced by a # character)</p><br>


<ul>Other Metacharacter :
	<li>. (	Find any character)</li>
	<li>^ (Finds a match as the beginning of a string as in: ^Hello)</li>
	<li>$ (Finds a match at the end of the string as in: World$)</li>
	<li>\d (Find any digits)</li>
	<li>\D (Find any non-digits)/li>
	<li>\s (Find any whitespace character)</li>
	<li>\S	(Find any non-whitespace character)</li>
	<li>\w	(Find any alphabetical letter (a to Z) and digit (0 to 9))</li>
	<li>\W	(Find any non-alphabetical and non-digit character)</li>
	<li>\b	(Find a match at the beginning of a word like this: \bWORD, or at the end of a word like this: WORD\b)</li>
	<li>\uxxxx	(Find the Unicode character specified by the hexadecimal number xxxx)</li>
</ul>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
