<!DOCTYPE html>
<html>
<body>

<p>No space</p>
<?php
$x = "Hello";
$y = "World";
$z = $x . $y;
echo $z;
?>

<hr>
<p>$x . " " . $y;</p>
<?php
$x = "Hello";
$y = "World";
$z = $x . " " . $y;
echo $z;
?>

<hr>
<p>$z = "$x $y"; echo $z;</p>
<?php
$x = "Hello";
$y = "World";
$z = "$x $y";
echo $z;
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>