<!DOCTYPE html>
<html>
<body>

<p>Uppercase</p>
<?php
$x = "Hello World!";
echo strtoupper($x);
?> 

<hr>
<p>Lowercase</p>
<?php
$x = "Hello World!";
echo strtolower($x);
?> 

<hr>
<p>Replace string</p>
<?php
$x = "Hello World!";
echo str_replace("World", "Dolly", $x);
?> 

<hr>
<p>Reverse string</p>
<?php
$x = "Hello World!";
echo strrev($x);
?> 

<hr>
<p>Remove Whitespace</p>
<?php
$x = " Hello World! ";
echo trim($x);
?> 

<p>The whitespaces are invisible in plain HTML,<br>
but check out the difference in two input fields:</p>

<?php
echo "<input value='" . $x . "'>";
echo "<br>";
echo "<input value='" . trim($x) . "'>";
?> 

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>