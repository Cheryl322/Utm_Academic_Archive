<!DOCTYPE html>
<html>
<body>

<?php
echo "Use a regular expression to do a case-insensitive count of the number of occurrences of "ain" in a string: <br>";
$str = "The rain in SPAIN falls mainly on the plains.";
$pattern = "/ain/i";
echo preg_match_all($pattern, $str);
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>