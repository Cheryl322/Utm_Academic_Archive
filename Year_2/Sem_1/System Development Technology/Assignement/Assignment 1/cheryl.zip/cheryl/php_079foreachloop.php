<!DOCTYPE html>
<html>
<body>

<?php  
echo "Loop through the items of an indexed array:";
$colors = array("red", "green", "blue", "yellow"); 

foreach ($colors as $x) {
  echo "$x <br>";
}
?>  

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
