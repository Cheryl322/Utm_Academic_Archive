<!DOCTYPE html>
<html>
<body>

<h1>Regex Modifier: +</h1>

<p>How many occurences of the character "n" are in the text "W3Schools has been live since 1999"?:</p>

<?php
$txt = "W3Schools has been live since 1999";
$pattern = "/n+/";
echo preg_match_all($pattern, $txt);
?>  

<p>The matches were found here:</p>

<?php
echo preg_replace($pattern, "#", $txt);
?>  

<p>(Each match was replaced by a # character)</p>

<br><br><a href="index.html">Back</a><br><br>

<br>
<ul>Other Quantifiers :
	<li>n*	(Matches any string that contains zero or more occurrences of n)</li>
	<li>n?	(Matches any string that contains zero or one occurrences of n)</li>
	<li>n{3} (Matches any string that contains a sequence of 3 n's)</li>
	<li>n{2, 5}	(Matches any string that contains a sequence of at least 2, but not more that 5 n's)</li>
	<li>n{3,}	(Matches any string that contains a sequence of at least 3 n's)</li>
</ul>

</body>
</html>
