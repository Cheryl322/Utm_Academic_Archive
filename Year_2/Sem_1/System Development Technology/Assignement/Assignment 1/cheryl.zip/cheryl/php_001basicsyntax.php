<!DOCTYPE html>
<html>
<body>

<h1>My first PHP page</h1>

<?php
echo "Hello World!";
?> 

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>