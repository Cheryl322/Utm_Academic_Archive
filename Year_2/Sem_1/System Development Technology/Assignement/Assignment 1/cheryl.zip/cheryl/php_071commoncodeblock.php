<!DOCTYPE html>
<html>
<body>

<?php
echo "More than one case for each code block: <br>";
$d = 10;

switch ($d) {
  case 1:
  case 2:
  case 3:
  case 4:
  case 5:  
    echo "The week feels so long!";
    break;
  case 6:
  case 0:
    echo "Weekends are the best!";
    break;
  default:
    echo "Something went wrong";
}
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>