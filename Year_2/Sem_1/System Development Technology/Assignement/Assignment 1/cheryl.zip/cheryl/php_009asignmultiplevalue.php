<!DOCTYPE html>
<html>
<body>

<?php
$x = $y = $z = "Fruit";

echo $x;
echo $y;
echo $z;

?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>