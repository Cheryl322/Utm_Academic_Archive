<!DOCTYPE html>
<html>
<body>

<?php
  echo "  If used inside a class, the class name is returned";
class Fruits {
  public function myValue(){
    return __CLASS__;
  }
}
$kiwi = new Fruits();
echo $kiwi->myValue();
?>

<hr>
<?php
echo "The directory of the file.";
echo __DIR__;
?>

<hr>
<?php
echo "  The file name including the full path.";
echo __FILE__;
?>

<hr>
<?php
echo "If inside a function, the function name is returned.";
function myValue(){
  return __FUNCTION__;
}
echo myValue();
?>

<hr>
<?php
echo "  The current line number.";
echo __LINE__;
?>

<hr>
<?php
  echo "If used inside a function that belongs to a class, both class and function name is returned.";
class Fruits {
  public function myValue(){
    return __METHOD__;
  }
}
$kiwi = new Fruits();
echo $kiwi->myValue();
?>

<hr>
<?php
echo "If used inside a trait, the trait name is returned.";
trait message1 {
  public function msg1() {
    echo __TRAIT__; 
  }
}

class Welcome {
  use message1;
}

$obj = new Welcome();
$obj->msg1();
?>

 
<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
