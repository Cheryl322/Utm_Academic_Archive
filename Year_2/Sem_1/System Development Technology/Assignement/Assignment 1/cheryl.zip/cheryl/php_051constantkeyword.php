<!DOCTYPE html>
<html>
<body>

<?php
const MYCAR = "Volvo";

echo MYCAR;
?> 

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
