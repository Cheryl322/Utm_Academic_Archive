<!DOCTYPE html>
<html>
<body>

<ul>
	<li>$a = 5;       // Integer</li>
	<li>$b = 5.34;    // Float</li>
	<li>$c = "25 kilometers"; // String</li>
	<li>$d = "kilometers 25"; // String</li>
	<li>$e = "hello"; // String</li>
	<li>$f = true;    // Boolean</li>
	<li>$g = NULL;    // NULL</li>
</ul>
<pre>
<?php
$a = 5;       // Integer
$b = 5.34;    // Float
$c = "25 kilometers"; // String
$d = "kilometers 25"; // String
$e = "hello"; // String
$f = true;    // Boolean
$g = NULL;    // NULL

$a = (int) $a;
$b = (int) $b;
$c = (int) $c;
$d = (int) $d;
$e = (int) $e;
$f = (int) $f;
$g = (int) $g;

//To verify the type of any object in PHP, use the var_dump() function:
var_dump($a);
var_dump($b);
var_dump($c);
var_dump($d);
var_dump($e);
var_dump($f);
var_dump($g);
?> 
</pre>

<p>Note that when casting a string that starts with a number, the (int) function uses that number. If it does not start with a number, the (int) function convert strings into the number 0.</p>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
