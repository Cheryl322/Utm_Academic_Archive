<!DOCTYPE html>
<html>
<body>

<?php 
echo "Stop, and jump to the next iteration if $i is 3:"; 
$i = 0;

while ($i < 6) {
  $i++;
  if ($i == 3) continue;  
  echo $i;
} 
?>  

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
