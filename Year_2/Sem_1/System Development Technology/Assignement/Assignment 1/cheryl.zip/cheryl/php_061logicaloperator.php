<!DOCTYPE html>
<html>
<body>

<h1>The and Operator</h1>

<p>Write a message if both conditions are true. if (x == 100 and y == 50)</p>

<?php
$x = 100;  
$y = 50;

if ($x == 100 and $y == 50) {
    echo "Hello world!";
}
?> 

<hr>
<h1>The or Operator</h1>

<p>Write a message if at least one of the conditions are true.if (x == 100 or y == 80) x=100,y=50</p>

<?php
$x = 100;  
$y = 50;

if ($x == 100 or $y == 80) {
    echo "Hello world!";
}
?>  

<hr>
<h1>The xor Operator</h1>

<p>Write a message if one of the conditions are true, bot not if both conditions are true.if (x == 100 xor y == 80) x=100,y=50</p>

<?php
$x = 100;  
$y = 50;

if ($x == 100 xor $y == 80) {
    echo "Hello world!";
}
?> 

<hr>
<h1>The && Operator</h1>

<p>Write a message if both conditions are true.if (x == 100 && y == 50)</p>

<?php
$x = 100;  
$y = 50;

if ($x == 100 && $y == 50) {
    echo "Hello world!";
}
?>

<hr>
<h1>The || Operator</h1>

<p>Write a message if at least one of the conditions are true.if (x == 100 || y == 80) x=100,y=50</p>

<?php
$x = 100;  
$y = 50;

if ($x == 100 || $y == 80) {
    echo "Hello world!";
}
?>   

<hr>
<h1>The ! Operator</h1>

<p>Write a message if the condition is NOT true.if (!(x == 90)). x=100</p>

<?php
$x = 100;  

if (!($x == 90)) {
    echo "Hello world!";
}
?>   

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
