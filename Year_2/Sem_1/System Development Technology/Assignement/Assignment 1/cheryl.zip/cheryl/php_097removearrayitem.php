<!DOCTYPE html>
<html>
<body>
<pre>

<?php  
$cars = array("Volvo", "BMW", "Toyota");
unset($cars[1]);
var_dump($cars);
echo "The unset() function does not re-arrange the indexes, meaning that after deletion the array will no longer contain the missing indexes.";
?>  

</pre>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
