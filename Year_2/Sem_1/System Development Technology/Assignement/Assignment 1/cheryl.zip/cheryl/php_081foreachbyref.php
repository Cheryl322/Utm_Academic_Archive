<!DOCTYPE html>
<html>
<body>

<pre>
<?php
echo "By default, changing an array item will not affect the original array:";
$colors = array("red", "green", "blue", "yellow");

foreach ($colors as $x) {
  if ($x == "blue") $x = "pink";
}

var_dump($colors);
?>
</pre>

<hr>
<pre>
<?php
echo "By assigning the array items by reference, changes will affect the original array:";
$colors = array("red", "green", "blue", "yellow");

foreach ($colors as &$x) {
  if ($x == "blue") $x = "pink";
}

var_dump($colors);
?>
</pre>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>