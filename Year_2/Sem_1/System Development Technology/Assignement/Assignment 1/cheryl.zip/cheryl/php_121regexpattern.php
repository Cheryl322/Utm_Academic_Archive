<!DOCTYPE html>
<html>
<body>

<h2>Regex Modifier: [co]</h2>

<p>How many occurences of the letters "c" or "o" are in the text "W3Schools.com":</p>

<?php
$txt = "W3Schools.com";
$pattern = "/[co]/";
echo preg_match_all($pattern, $txt);
?>  

<p>The matches were found here:</p>

<?php
echo preg_replace($pattern, "#", $txt);
?>  

<p>(Each match was replaced by a # character)</p>

<hr>
<h2>Regex Modifier: [^eo]</h2>

<p>How many letters in the text "Welcome" are not "e" or "o":</p>

<?php
$txt1 = "Welcome";
$pattern1 = "/[^eo]/";
echo preg_match_all($pattern1, $txt1);
?>  

<p>The matches were found here:</p>

<?php
echo preg_replace($pattern1, "#", $txt1);
?>  

<p>(Each match was replaced by a # character)</p>

<hr>
<h2>Regex Modifier: [e-o]</h2>

<p>How many letters in the text "Welcome" are alphabetically between "e" and "o":</p>

<?php
$txt2 = "Welcome";
$pattern2 = "/[e-o]/";
echo preg_match_all($pattern2, $txt2);
?>  

<p>The matches were found here:</p>

<?php
echo preg_replace($pattern2, "#", $txt2);
?>  

<p>(Each match was replaced by a # character)</p>

<hr>
<h2>Regex Modifier: [T-e]</h2>

<p>How many letters in the text "Welcome to W3Schools" are alphabetically between uppercase "T" and lowercase "e":</p>

<?php
$txt3 = "Welcome to W3Schools";
$pattern3 = "/[T-e]/";
echo preg_match_all($pattern3, $txt3);
?>  

<p>The matches were found here:</p>

<?php
echo preg_replace($pattern3, "#", $txt3);
?>  

<p>(Each match was replaced by a # character)</p>

<hr>



<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
