<!DOCTYPE html>
<html>
<body>

<?php
echo "100 == 100 <br> Returns true if x is equal to y <br>";
$x = 100;  
$y = "100";

var_dump($x == $y); // returns true because values are equal
?>

<hr>
<?php
echo "100 === 100 <br> Returns true if x is equal to y, and they are of the same type <br>";
$x = 100;  
$y = "100";

var_dump($x === $y); // returns false because types are not equal
?>

<hr>
<?php
echo "100 != 100 <br> Returns true if x is not equal to y <br>";
$x = 100;  
$y = "100";

var_dump($x != $y); // returns false because values are equal
?>

<hr>
<?php
echo "100 <> 100 <br> Returns true if x is not equal to y <br>";
$x = 100;  
$y = "100";

var_dump($x <> $y); // returns false because values are equal
?>

<hr>
<?php
echo "100 !== 100 <br> Returns true if x is not equal to y, or they are not of the same type <br>";
$x = 100;  
$y = "100";

var_dump($x !== $y); // returns true because types are not equal
?>

<hr>
<?php
echo "100 > 50 <br> Returns true if x is greater than y <br>";
$x = 100;
$y = 50;

var_dump($x > $y); // returns true because $x is greater than $y
?>

<hr>
<?php
echo "10 < 50 <br> Returns true if x is less than y <br>";
$x = 10;
$y = 50;

var_dump($x < $y); // returns true because $x is less than $y
?>

<hr>
<?php
echo "50 >= 50 <br> Returns true if x is greater than or equal to y <br>";
$x = 50;
$y = 50;

var_dump($x >= $y); // returns true because $x is greater than or equal to $y
?>

<hr>
<?php
echo "50 <= 50 <br> Returns true if x is less than or equal to y <br>";
$x = 50;
$y = 50;

var_dump($x <= $y); // returns true because $x is less than or equal to $y
?>

<hr>
<?php
echo "Returns an integer less than, equal to, or greater than zero, depending on if x is less than, equal to, or greater than y. Introduced in PHP 7. <br> ";
echo "5<=>10 <br> returns -1 because x is less than y";
$x = 5;  
$y = 10;

echo ($x <=> $y); 
echo "<br>";

echo "10<=>10 <br> returns 0 because values are equal";
$x = 10;  
$y = 10;

echo ($x <=> $y); 
echo "<br>";

echo "15<=>10 <br> returns +1 because x is greater than y";
$x = 15;  
$y = 10;

echo ($x <=> $y); 
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>