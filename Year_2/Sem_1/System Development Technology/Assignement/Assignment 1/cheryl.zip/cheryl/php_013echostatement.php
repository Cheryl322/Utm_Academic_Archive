<!DOCTYPE html>
<html>
<body>

<?php
echo "Hello";
//same as:
echo("Hello");
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
