<!DOCTYPE html>
<html>
<body>

<?php declare(strict_types=1); // strict requirement
function addNumbers(float $a, float $b) : float {
  return $a + $b;
}
echo " Like with the type declaration for function arguments, by enabling the strict requirement, it will throw a "Fatal Error" on a type mismatch.<br>To declare a type for the function return, add a colon ( : ) and the type right before the opening curly ( { )bracket when declaring the function.";
echo "1.2+5.2= ". addNumbers(1.2, 5.2). "<br>";
?>

<hr>
<?php declare(strict_types=1); // strict requirement
function addNumbers(float $a, float $b) : int {
  return (int)($a + $b);
}
echo "1.2+5.2= ". addNumbers(1.2, 5.2); 
?>


<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
