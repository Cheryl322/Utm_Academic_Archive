<!DOCTYPE html>
<html>
<body>

<?php
echo "random number between ";
echo "<br>";
echo(rand());
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
