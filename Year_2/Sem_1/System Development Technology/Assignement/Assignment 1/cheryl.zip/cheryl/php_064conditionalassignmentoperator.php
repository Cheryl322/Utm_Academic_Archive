<!DOCTYPE html>
<html>
<body>

<?php
   echo "if empty(user) = TRUE, set status = (anonymous)";
   echo $status = (empty($user)) ? "anonymous" : "logged in";
   echo("<br>");

   $user = "John Doe";
   echo "if empty(user) = FALSE, set status = (logged in)";
   echo $status = (empty($user)) ? "anonymous" : "logged in";
?>  

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
