<!DOCTYPE html>
<html>
<body>

<?php
$x = "We are the so-called \"Vikings\" from the north.";
echo $x;
?> 

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>