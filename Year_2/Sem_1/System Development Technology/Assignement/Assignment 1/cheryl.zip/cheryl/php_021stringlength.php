<!DOCTYPE html>
<html>
<body>

<p>strlen("Hello world!")</p>
<?php
echo strlen("Hello world!");
?> 
 
 <br><br><a href="index.html">Back</a><br><br>

</body>
</html>
