<!DOCTYPE html>
<html>
<body>

<p>check 5985</p>
<?php
// Check if the type of a variable is integer   
$x = 5985;
var_dump(is_int($x));

echo "<br>";

<br><p>check 59.85</p>
// Check again... 
$x = 59.85;
var_dump(is_int($x));
?>  

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>