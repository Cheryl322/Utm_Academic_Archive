<!DOCTYPE html>
<html>
<body>

<?php
// echo "Welcome Home!";
?>

<?php
echo "Welcome Home!"; // Outputs a welcome message
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
