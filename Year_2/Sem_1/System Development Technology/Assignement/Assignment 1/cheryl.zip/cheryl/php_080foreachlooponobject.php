<!DOCTYPE html>
<html>
<body>

<?php
echo "Print the property names and values of the $myCar object:";
class Car {
  public $color;
  public $model;
  public function __construct($color, $model) {
    $this->color = $color;
    $this->model = $model;
  }
}

$myCar = new Car("red", "Volvo");

foreach ($myCar as $x => $y) {
  echo "$x: $y<br>";
}
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>