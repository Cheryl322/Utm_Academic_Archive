<!DOCTYPE html>
<html>
<body>

<?php
$x = 5; // global scope
 
function myTest() {
  // using x inside this function will generate an error
  echo "<p>Variable x inside function is: $x</p>";
} 
myTest();

echo "<p>Variable x outside function is: $x</p>";
?>
<hr>

<?php
function myTest1() {
  $y = 5; // local scope
  echo "<p>Variable x inside function is: $y</p>";
} 
myTest1();

//using x outside the function will generate an error
echo "<p>Variable Y outside function is: $y</p>";
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>
