<!DOCTYPE html>
<html>
<body>


<?php
echo "min(0, 150, 30, 20, -8, -200)";
echo "<br>";
echo(min(0, 150, 30, 20, -8, -200) . "<br>");
echo "max(0, 150, 30, 20, -8, -200)";
echo "<br>";
echo(max(0, 150, 30, 20, -8, -200));
?>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>