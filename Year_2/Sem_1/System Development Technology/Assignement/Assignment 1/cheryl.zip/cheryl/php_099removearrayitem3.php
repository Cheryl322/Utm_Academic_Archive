<!DOCTYPE html>
<html>
<body>
<pre>

<?php  
echo "Create a new array, without "Mustang" and "1964": <br>";
$cars = array("brand" => "Ford", "model" => "Mustang", "year" => 1964);
$newarray = array_diff($cars, ["Mustang", 1964]);
var_dump($newarray);
echo "Note: The array_diff() function takes values as parameters, and not keys.";
?>  

</pre>

<br><br><a href="index.html">Back</a><br><br>

</body>
</html>