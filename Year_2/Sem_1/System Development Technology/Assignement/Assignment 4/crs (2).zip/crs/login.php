<?php include 'headermain.php'; ?>

<div class="container">
  
  <br><br><h5>Please fill to login</h5><br>

  <form method="POST" action="loginprocess.php">
    <fieldset>
      <div>
        <label for="exampleInputEmail1" class="form-label mt-4">Enter your staff or student number</label>
        <input type="text" name="funame" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter your staff or student ID" required>
      </div>
      
       <div>
        <label for="exampleInputPassword1" class="form-label mt-4">Enter Password</label>
        <input type="password" name="fpwd" class="form-control" id="exampleInputPassword1" placeholder="Enter password" autocomplete="off" required>
      </div>

     
      <br>
      <button type="submit" class="btn btn-primary">Login</button>
      <br><br><br><br><br>
  </fieldset>
</form>
   
</div>

<?php include 'footer.php'; ?>