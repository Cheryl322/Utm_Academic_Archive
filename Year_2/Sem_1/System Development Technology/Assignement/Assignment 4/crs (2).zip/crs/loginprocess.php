<?php
session_start();

//Connect to Database
include('dbconnect.php');

//Retrieve data from form
$funame = $_POST['funame'];
$fpwd = $_POST['fpwd'];


//SQL Insert operation
$sql="SELECT * FROM tb_user 
		WHERE u_sno='$funame' AND u_pwd='$fpwd'";

//Execute SQL
$result=mysqli_query($con,$sql);

//Retrieve data
$row=mysqli_fetch_array($result);

//Count result to check
$count=mysqli_num_rows($result);

//Rule-based AI login
if($count == 1)
{
	//set session
	$_SESSION['u_sno']= session_id();
	$_SESSION['funame']= $funame;//funame不是database的

	if($row['u_utype'] == 1)//check user type
	{
		//Lecturer
		header('Location: lecturer.php');

	}
	if($row['u_utype'] == 2)//check user type
	{
		//Student
		header('Location: student.php');
	}
	if($row['u_utype'] == 3)//check user type
	{
		//IT
		header('Location: staff.php');

	}
}
else
{
	//Redirect to login error page
	header('Location: login.php');

}


//Close connection
mysqli_close($con);


?>