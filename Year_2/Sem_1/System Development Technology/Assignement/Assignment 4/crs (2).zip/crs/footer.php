<div class="footer">
  <p>Crs developed by Cheryl @ 2024</p>
</div>

</body>
</html>