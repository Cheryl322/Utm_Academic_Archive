<?php include 'headermain.php'; ?>

<div class="container">
  
  <br><br><h5>Please fill all following details</h5><br>

  <form method="POST" action="registerprocess.php">
    <fieldset>
      <div>
        <label for="exampleInputEmail1" class="form-label mt-4">Please enter your staff or student number</label>
        <input type="text" name="funame" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter your staff or student ID" required>
      </div>
      
       <div>
        <label for="exampleInputPassword1" class="form-label mt-4">Create your Password</label>
        <input type="password" name="fpwd" class="form-control" id="exampleInputPassword1" placeholder="Create password" autocomplete="off" required>
      </div>

      <div>
        <label for="exampleInputEmail1" class="form-label mt-4">Email address</label>
        <input type="email" name="femail" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" required>
      </div>

      <div>
        <label for="exampleInputEmail1" class="form-label mt-4">Enter your full name</label>
        <input type="text" name="fname" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter your your full name according to IC"required>
        
      </div>

      <div>
        <label for="exampleInputEmail1" class="form-label mt-4">Enter your contact number</label>
        <input type="text" name="fcontact" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Your mobile or fixed line number" required>
      </div>

      <div>
        <label for="exampleSelect1" class="form-label mt-4">Select  your state</label>
        <select class="form-select" name="fstate" id="exampleSelect1">
          <option>Johor</option>
          <option>Kedah</option>
          <option>Kelantan</option>
          <option>Negeri Sembilan</option>
          <option>Melaka</option>
          <option>Pahang</option>
          <option>Penang</option>
          <option>Perak</option>
          <option>Perlis</option>
          <option>Sabah</option>
          <option>Sarawak</option>
          <option>Selangor</option>
          <option>Terengganu</option>
          <option>W.P. Kuala Lumpur</option>
          <option>W.P. Labuan</option>
          <option>W.P. Putrajaya</option>
        </select>
      </div>
      
      <br>
      <button type="submit" class="btn btn-primary">Submit</button>
      <button type="submit" class="btn btn-danger">Clear Form</button>
      <br><br><br><br><br>
  </fieldset>
</form>
   
</div>

<?php include 'footer.php'; ?>